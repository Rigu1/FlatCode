import styled from 'styled-components';

const StyledHomePage = styled.div`
  display: flex;
  justify-content: center;
`;

export default StyledHomePage;