import styled from 'styled-components';

export const StyledHomePage = styled.div`
  display: flex;
  justify-content: center;
`;