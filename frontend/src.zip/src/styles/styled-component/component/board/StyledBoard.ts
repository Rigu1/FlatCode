import styled from 'styled-components';

export const StyledBoard = styled.div`
  width: 30vw;
  height: 40vh;
  background-color: #131313;
  border-radius: 15px;
`;