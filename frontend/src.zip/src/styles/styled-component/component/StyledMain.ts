import styled from 'styled-components';

export const StyledMain = styled.div`
  padding: 1em 2em;
  flex-grow: 1;
  height: 100vh;
  background-color: #0E0E0E;
`;