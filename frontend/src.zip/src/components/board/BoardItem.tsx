import React from 'react';
import { StyledBoard } from '@styles/styled-component/component/board/StyledBoard';

const BoardItem: React.FC = () => {
  return (
    <StyledBoard>
      
    </StyledBoard>
  );
};

export default BoardItem;