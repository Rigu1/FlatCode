import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:5000/api',
  withCredentials: true, // 쿠키를 포함하여 요청
});

export default axiosInstance;
