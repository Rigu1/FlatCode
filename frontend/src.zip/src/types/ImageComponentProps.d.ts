export interface ImageComponentProps {
  src: string;
  alt: string;
  className?: string;
}
