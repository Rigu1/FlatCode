import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface ChatState {
  prompt: string;
  response: string;
  loading: boolean;
  error: string | null;
}

const initialState: ChatState = {
  prompt: '',
  response: '',
  loading: false,
  error: null,
};

export const fetchChatResponse = createAsyncThunk(
  'chat/fetchChatResponse',
  async (prompt: string) => {
    const response = await axios.post('http://localhost:5001/api/chat/chat', {
      prompt,
    });
    return response.data.answer;
  },
);

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    setPrompt(state, action) {
      state.prompt = action.payload;
    },
    clearResponse(state) {
      state.response = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchChatResponse.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchChatResponse.fulfilled, (state, action) => {
        state.loading = false;
        state.response = action.payload;
      })
      .addCase(fetchChatResponse.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || 'Failed to get response from ChatGPT';
      });
  },
});

export const { setPrompt, clearResponse } = chatSlice.actions;
export default chatSlice.reducer;
